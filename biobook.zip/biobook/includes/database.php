<?php
mysql_select_db('biobook',mysql_connect('localhost','root',''))or die(mysql_error());
?>
